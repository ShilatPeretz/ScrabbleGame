package Model;

import Model.scrabbleModel;

public class ModelMain {
    public static void main(String[] args) {
        scrabbleModel scrabbleModel = new scrabbleModel();
        scrabbleModel.initializeGame();

    }
}
