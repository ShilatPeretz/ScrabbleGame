package BookScrabbleServer;

import  BookScrabbleServer.BookScrabbleServer;
public class ServerMain {

    public static void main(String[] args) {
        BookScrabbleServer bookScrabbleServer = new BookScrabbleServer();
        bookScrabbleServer.run();
    }

}
