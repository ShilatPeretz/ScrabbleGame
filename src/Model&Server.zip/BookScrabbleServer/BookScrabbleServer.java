package BookScrabbleServer;

import test.Board;
import test.BookScrabbleHandler;
import test.ClientHandler;
import test.MyServer;

import java.util.List;
import java.util.Random;

public class BookScrabbleServer {
    private final MyServer gameServer;
    private int gamePort;
    //functions
    public BookScrabbleServer(){
        /** return 4 digits number so that other players can connect to the game*/
        Random r=new Random();
        this.gamePort=6667;
        this.gameServer = new MyServer(gamePort, new BookScrabbleHandler());
    };
    public void run(){
        this.gameServer.start();
    }
}
